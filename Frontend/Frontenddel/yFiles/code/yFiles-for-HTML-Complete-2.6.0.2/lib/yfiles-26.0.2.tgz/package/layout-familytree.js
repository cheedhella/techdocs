/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 2.6.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2023 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/
import y from"./impl/layout-familytree.js";export var FamilyTreeLayout=y.genealogy.FamilyTreeLayout;export var FamilyType=y.genealogy.FamilyType;export var VerticalNodeAlignment=y.genealogy.VerticalNodeAlignment;export var FamilyMembersSortingPolicy=y.genealogy.FamilyMembersSortingPolicy;export default y;