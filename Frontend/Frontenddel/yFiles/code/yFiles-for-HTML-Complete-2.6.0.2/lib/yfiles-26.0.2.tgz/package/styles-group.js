/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 2.6.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2023 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/
import y from"./impl/styles-group.js";export var GroupNodeLabelModel=y.graph.GroupNodeLabelModel;export var GroupNodeStyle=y.styles.GroupNodeStyle;export var GroupNodeStyleRenderer=y.styles.GroupNodeStyleRenderer;export default y;