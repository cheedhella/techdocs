@echo off
start cmd /k "mvn spring-boot:run -pl employees-service"
start cmd /k "mvn spring-boot:run -pl products-service"