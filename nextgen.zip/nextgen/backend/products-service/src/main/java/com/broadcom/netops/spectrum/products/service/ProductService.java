package com.broadcom.netops.spectrum.products.service;

import org.springframework.stereotype.Service;

import com.broadcom.netops.spectrum.products.model.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    private final List<Product> products = new ArrayList<>();

    public List<Product> findAll() {
        Product product1 = Product.builder()
                .id(1L)
                .name("Product A")
                .description("Description for Product A")
                .price(99.99)
                .build();
        Product product2 = Product.builder().
                id(2L)
                .name("Product B")
                .description("Description for Product B")
                .price(149.99)
                .build();
        products.add(product1);
        products.add(product2);
        return products;
    }

    public Optional<Product> findById(Long id) {
        return products.stream().filter(product -> product.getId().equals(id)).findFirst();
    }

    public Product save(Product product) {
        products.add(product);
        return product;
    }

    public Optional<Product> update(Long id, Product productDetails) {
        return findById(id).map(product -> {
            product.setName(productDetails.getName());
            product.setDescription(productDetails.getDescription());
            product.setPrice(productDetails.getPrice());
            return product;
        });
    }
}