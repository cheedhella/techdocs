#!/bin/bash
mvn spring-boot:run -pl employees-service &
mvn spring-boot:run -pl products-service &
wait
