package com.broadcom.netops.spectrum.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeesApplicationTests {

    @Test
    void contextLoads() {
    }
}