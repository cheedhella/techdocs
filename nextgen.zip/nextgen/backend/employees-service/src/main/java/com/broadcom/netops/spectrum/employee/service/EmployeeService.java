package com.broadcom.netops.spectrum.employee.service;

import com.broadcom.netops.spectrum.employee.model.Employee;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeService {

    private final List<Employee> employees = new ArrayList<>();

    public List<Employee> findAll() {
        Employee e1 = Employee.builder().id(1L).name("Alice").role("Developer").build();
        Employee e2 = Employee.builder().id(2L).name("Bob").role("Manager").build();
        employees.add(e1);
        employees.add(e2);
        return employees;
    }

    public Employee save(Employee employee) {
        employees.add(employee);
        return employee;
    }
}