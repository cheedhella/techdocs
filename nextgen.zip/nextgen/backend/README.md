# Multi-Module Spring Boot Application

This project is a multi-module Spring Boot application consisting of three main services: Products, Employees, and Data, along with a Mock API for simulating responses.

## Project Structure

- **products-service**: A Spring Boot application that manages products.
- **employees-service**: A Spring Boot application that manages employees.
- **data-service**: A Spring Boot application that manages data items.
- **mock-api**: A Spring Boot application that simulates API responses for products, employees, and data items.

## Getting Started

### Prerequisites

- Java 11 or higher
- Maven 3.6 or higher

### Building the Project

To build the entire project, navigate to the root directory of the project and run:

```
mvn clean install
```

### Running the Services

Each service can be run independently. Navigate to the respective service directory and execute:

```
mvn spring-boot:run
```

### API Endpoints

- **Products Service**: 
  - `GET /products`
  - `GET /products/{id}`
  - `POST /products`
  - `PUT /products/{id}`

- **Employees Service**: 
  - `GET /employees`
  - `GET /employees/{id}`
  - `POST /employees`
  - `PUT /employees/{id}`

- **Data Service**: 
  - `GET /data`
  - `GET /data/{id}`
  - `POST /data`
  - `PUT /data/{id}`

- **Mock API**: 
  - Simulates responses for the above services.

## Testing

Each service contains unit tests located in the `src/test` directory. To run the tests, navigate to the service directory and execute:

```
mvn test
```

## License

This project is licensed under the MIT License.