import { createRootRoute, createRoute, createRouter, Link, Outlet, redirect } from "@tanstack/react-router";
import LoginPage from "./pages/login/LoginPage";
import useAuthStore from "./stores/useAuthStore";
import HomePage from "./pages/home/HomePage";
import SystemStatus from "./pages/health/SystemStatus";
import { SettingsPage } from "./pages/settings/SettingsPage";
import CreateUser from "./pages/settings/users/CreateUser";
import ListUsers from "./pages/settings/users/ListUsers";
import { NotFound } from "./pages/misc/NotFound";

const rootRoute = createRootRoute({
    component: () => <Outlet />,
    notFoundComponent: NotFound,
});

const loginRoute = createRoute({
    getParentRoute: () => rootRoute,
    path: "/login",
    component: LoginPage,
});

const homeRoute = createRoute({
    getParentRoute: () => rootRoute,
    path: "/home",
    beforeLoad: () => {
        const isLoggedIn = useAuthStore.getState().isLoggedIn;
        if (!isLoggedIn) throw redirect({ to: "/login" });
    },
    component: HomePage,
});

const systemStatusRoute = createRoute({
    getParentRoute: () => rootRoute,
    path: "/systemStatus",
    beforeLoad: () => {
        const isLoggedIn = useAuthStore.getState().isLoggedIn;
        if (!isLoggedIn) throw redirect({ to: "/login" });
    },
    component: SystemStatus,
});

const indexRoute = createRoute({
    getParentRoute: () => rootRoute,
    path: "/",
    loader: () => {
        throw redirect({ to: "/login" });
    },
});


export const settingsRootRoute = createRoute({
    getParentRoute: () => rootRoute,
    path: "/settings",
    component: () => <Outlet />,
    beforeLoad: () => {
        const isLoggedIn = useAuthStore.getState().isLoggedIn;
        if (!isLoggedIn) throw redirect({ to: "/login" });
    },
    notFoundComponent: NotFound,
});

export const settingsHomeRoute = createRoute({
    getParentRoute: () => rootRoute,
    path: "/settings/home",
    component: SettingsPage,
    beforeLoad: () => {
        const isLoggedIn = useAuthStore.getState().isLoggedIn;
        if (!isLoggedIn) throw redirect({ to: "/login" });
    },
});

const addUserRoute = createRoute({
    getParentRoute: () => settingsRootRoute,
    path: "create-user",
    component: CreateUser,
    beforeLoad: () => {
        const isLoggedIn = useAuthStore.getState().isLoggedIn;
        if (!isLoggedIn) throw redirect({ to: "/login" });
    },
});

const listUsersRoute = createRoute({
    getParentRoute: () => settingsRootRoute,
    path: "list-users",
    component: ListUsers,
    beforeLoad: () => {
        const isLoggedIn = useAuthStore.getState().isLoggedIn;
        if (!isLoggedIn) throw redirect({ to: "/login" });
    },
});

// Redirect from the old /settings/home to the new /settings root
/*
const settingsRedirectRoute = createRoute({
    getParentRoute: () => rootRoute,
    path: '/settings/home',
    loader: () => redirect({ to: '/settings', replace: true })
})*/

settingsRootRoute.addChildren([settingsHomeRoute, addUserRoute, listUsersRoute]);

const routeTree = rootRoute.addChildren([
    indexRoute,
    loginRoute,
    homeRoute,
    systemStatusRoute,
    settingsRootRoute,
]);

export const routerInstance = createRouter({ routeTree });