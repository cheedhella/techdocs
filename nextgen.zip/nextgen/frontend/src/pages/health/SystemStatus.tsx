import { useState } from "react";
import {
    Box,
    Typography,
    Divider,
    Chip,
    IconButton,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Stack,
    Button,
} from "@mui/material";
import RefreshIcon from "@mui/icons-material/Refresh";
import Layout from "../LayoutPage";

// Mock grouped service data
const initialServiceGroups: {
    groupName: string;
    services: { name: string; status: string; lastChecked: string }[];
}[] = [
        {
            groupName: "SpectroSERVERs",
            services: [
                { name: "SpectroSERVER - Primary", status: "Running", lastChecked: "11:10 AM" },
                { name: "SpectroSERVER - Secondary", status: "Stopped", lastChecked: "11:08 AM" },
            ],
        },
        {
            groupName: "OneClick Servers",
            services: [
                { name: "OneClick Web - Server1", status: "Running", lastChecked: "11:09 AM" },
                { name: "OneClick Web - Server2", status: "Degraded", lastChecked: "11:07 AM" },
            ],
        },
        {
            groupName: "Core Services",
            services: [
                { name: "Archive Manager (DDM)", status: "Running", lastChecked: "11:05 AM" },
                { name: "Process Daemon", status: "Stopped", lastChecked: "11:03 AM" },
                { name: "MySQL / Database", status: "Running", lastChecked: "11:00 AM" },
            ],
        },
    ];

// Helper to map status → chip color
const getStatusColor = (status: string) => {
    switch (status) {
        case "Running":
            return "success";
        case "Degraded":
            return "warning";
        case "Stopped":
            return "error";
        default:
            return "default";
    }
};

// Helper to summarize group status
const getGroupSummary = (services: { status: string }[]) => {
    const total = services.length;
    const running = services.filter((s) => s.status === "Running").length;
    const stopped = services.filter((s) => s.status === "Stopped").length;
    const degraded = services.filter((s) => s.status === "Degraded").length;

    if (stopped > 0) return { label: `${running}/${total} Running (${stopped} Stopped)`, color: "error" };
    if (degraded > 0) return { label: `${running}/${total} Running (${degraded} Degraded)`, color: "warning" };
    return { label: `${running}/${total} Running`, color: "success" };
};

export default function SystemStatus() {
    const [serviceGroups, setServiceGroups] = useState(initialServiceGroups);

    const handleRefresh = (groupName: string) => {
        console.log(`Refreshing group: ${groupName}`);
        // TODO: fetch latest statuses from API
    };

    const handleStart = (serviceName: string) => {
        console.log(`Starting service: ${serviceName}`);
        // TODO: API call to start service
    };

    const handleStop = (serviceName: string) => {
        console.log(`Stopping service: ${serviceName}`);
        // TODO: API call to stop service
    };

    return (
        <Layout>
            <Box sx={{ p: 3 }}>
                <Typography variant="h4" gutterBottom>
                    Spectrum System Status
                </Typography>
                <Divider sx={{ mb: 3 }} />

                {serviceGroups.map((group, idx) => {
                    const summary = getGroupSummary(group.services);

                    return (
                        <Box key={idx} sx={{ mb: 4 }}>
                            {/* Group Header */}
                            <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 1 }}>
                                <Typography variant="h6">{group.groupName}</Typography>
                                <Chip label={summary.label} color={summary.color as any} />
                                <IconButton onClick={() => handleRefresh(group.groupName)} size="small">
                                    <RefreshIcon />
                                </IconButton>
                            </Stack>

                            {/* Group Table */}
                            <TableContainer component={Paper}>
                                <Table size="small">
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Service</TableCell>
                                            <TableCell>Status</TableCell>
                                            <TableCell>Last Checked</TableCell>
                                            <TableCell align="right">Action</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {group.services.map((service, index) => (
                                            <TableRow key={index}>
                                                <TableCell>{service.name}</TableCell>
                                                <TableCell>
                                                    <Chip
                                                        label={service.status}
                                                        color={getStatusColor(service.status)}
                                                        size="small"
                                                    />
                                                </TableCell>
                                                <TableCell>{service.lastChecked}</TableCell>
                                                <TableCell align="right">
                                                    {service.status === "Running" && (
                                                        <Button
                                                            size="small"
                                                            color="error"
                                                            variant="outlined"
                                                            onClick={() => handleStop(service.name)}
                                                        >
                                                            Stop
                                                        </Button>
                                                    )}
                                                    {service.status === "Stopped" && (
                                                        <Button
                                                            size="small"
                                                            color="success"
                                                            variant="outlined"
                                                            onClick={() => handleStart(service.name)}
                                                        >
                                                            Start
                                                        </Button>
                                                    )}
                                                    {service.status === "Degraded" && (
                                                        <Stack direction="row" spacing={1} justifyContent="flex-end">
                                                            <Button
                                                                size="small"
                                                                color="error"
                                                                variant="outlined"
                                                                onClick={() => handleStop(service.name)}
                                                            >
                                                                Stop
                                                            </Button>
                                                            <Button
                                                                size="small"
                                                                color="success"
                                                                variant="outlined"
                                                                onClick={() => handleStart(service.name)}
                                                            >
                                                                Restart
                                                            </Button>
                                                        </Stack>
                                                    )}
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Box>
                    );
                })}
            </Box>
        </Layout>
    );
}
