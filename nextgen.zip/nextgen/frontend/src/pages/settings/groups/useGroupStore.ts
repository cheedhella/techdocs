import { create } from "zustand";

export interface Group {
    id: number;
    name: string;
    description: string;
    type: "Static" | "Dynamic";
    members: number;
    condition: "Normal" | "Minor" | "Critical";
}

export interface GroupStore {
    groups: Group[];
    addGroup: (group: Group) => void;
}

export const useGroupStore = create<GroupStore>((set) => ({
    groups: [
        {
            id: 1,
            name: "Routers",
            description: "All Cisco and Juniper routers",
            type: "Dynamic",
            members: 15,
            condition: "Normal",
        },
        {
            id: 2,
            name: "Critical Devices",
            description: "Devices currently in critical state",
            type: "Dynamic",
            members: 7,
            condition: "Critical",
        },
        {
            id: 3,
            name: "Data Center Switches",
            description: "Core and access switches in DC1",
            type: "Static",
            members: 24,
            condition: "Minor",
        },
    ],
    addGroup: (group) => set((state) => ({ groups: [...state.groups, group] })),
}));