import React from "react";
import {
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Typography,
  Divider,
  Box,
  Chip,
  Stack,
} from "@mui/material";
import FolderIcon from "@mui/icons-material/Folder";
import { useGroupStore, type Group } from "./useGroupStore";

// Helper for condition chips
const ConditionChip: React.FC<{ condition: Group["condition"] }> = ({ condition }) => {
  let color: "default" | "success" | "warning" | "error" = "default";
  if (condition === "Normal") color = "success";
  if (condition === "Minor") color = "warning";
  if (condition === "Critical") color = "error";

  return <Chip label={condition} color={color} size="small" />;
};

const GroupList: React.FC = () => {
  const { groups } = useGroupStore();

  return (
    <Box sx={{ maxWidth: 500, margin: "auto", p: 2 }}>
      <Stack direction="row" spacing={2} alignItems="center" sx={{ mb: 2 }}>
        <Typography variant="h6" component="h1">
          Spectrum Groups
        </Typography>
      </Stack>
      <Divider />
      <List>
        {groups.map((group: Group) => (
          <ListItem key={group.id} alignItems="flex-start">
            <ListItemIcon>
              <FolderIcon />
            </ListItemIcon>
            <ListItemText
              primary={
                <Box display="flex" justifyContent="space-between" alignItems="center">
                  <Typography variant="subtitle1">{group.name}</Typography>
                  <ConditionChip condition={group.condition} />
                </Box>
              }
              secondary={
                <>
                  <Typography variant="body2" color="text.secondary">
                    {group.description}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {group.type} • {group.members} members
                  </Typography>
                </>
              }
            />
          </ListItem>
        ))}
      </List>
    </Box>
  );
};

export default GroupList;
