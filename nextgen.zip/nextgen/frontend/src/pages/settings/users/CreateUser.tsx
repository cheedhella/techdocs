import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
    Button,
    Card,
    CardContent,
    TextField,
    Typography,
    Stack,
} from "@mui/material";
import Layout from "../../LayoutPage";

export default function CreateUser() {
    const navigate = useNavigate();
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [role, setRole] = useState("");
    const [error, setError] = useState("");

    const handleSave = async () => {
        // Simple validation
        if (!name || !email || !role) {
            setError("All fields are required.");
            return;
        }

        setError("");

        // Dummy backend call simulation
        await new Promise((resolve) => setTimeout(resolve, 1000));
        console.log("User created:", { name, email, role });

        // Navigate back to parent route
        navigate({ to: "../home" });
    };

    const handleCancel = () => {
        navigate({ to: "../home" });
    };

    return (
        <Layout>
            <div style={{ padding: "24px", display: "flex", justifyContent: "center" }}>
                <Card sx={{ maxWidth: 500, width: "100%", borderRadius: 3 }}>
                    <CardContent>
                        <Typography variant="h6" gutterBottom>
                            Create User
                        </Typography>
                        <Stack spacing={2}>
                            <TextField
                                label="Name"
                                variant="outlined"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                fullWidth
                            />
                            <TextField
                                label="Email"
                                variant="outlined"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                fullWidth
                            />
                            <TextField
                                label="Role"
                                variant="outlined"
                                value={role}
                                onChange={(e) => setRole(e.target.value)}
                                fullWidth
                            />
                            {error && (
                                <Typography variant="body2" color="error">
                                    {error}
                                </Typography>
                            )}
                            <Stack direction="row" spacing={2} justifyContent="flex-end">
                                <Button variant="outlined" onClick={handleCancel}>
                                    Cancel
                                </Button>
                                <Button variant="contained" onClick={handleSave}>
                                    Save
                                </Button>
                            </Stack>
                        </Stack>
                    </CardContent>
                </Card>
            </div>
        </Layout>
    );
}