import { useNavigate } from "@tanstack/react-router";
import { Button, Card, CardContent, Typography, Chip, Grid } from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import Layout from "../../LayoutPage";

// Mock data for users
const users = [
    { id: 1, name: "Alice Johnson", email: "alice@example.com", role: "Admin" },
    { id: 2, name: "Bob Smith", email: "bob@example.com", role: "Editor" },
    { id: 3, name: "Charlie Brown", email: "charlie@example.com", role: "Viewer" },
    { id: 4, name: "Dana White", email: "dana@example.com", role: "Editor" },
];

export default function ListUsers() {
    const navigate = useNavigate();

    return (
        <Layout>
            <div style={{ padding: "24px" }}>
                {/* Back Button */}
                <Button
                    variant="outlined"
                    startIcon={<ArrowBackIcon />}
                    onClick={() => navigate({ to: "../home" })}
                    sx={{ mb: 3 }}
                >
                    Back
                </Button>

                {/* Users Grid */}
                <Grid container spacing={3}>
                    {users.map((user) => (
                        <Grid item xs={12} sm={6} md={4} key={user.id}>
                            <Card elevation={3} sx={{ borderRadius: 3 }}>
                                <CardContent>
                                    <Typography variant="h6" gutterBottom>
                                        {user.name}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        {user.email}
                                    </Typography>
                                    <Chip
                                        label={user.role}
                                        size="small"
                                        sx={{ mt: 1 }}
                                    />
                                </CardContent>
                            </Card>
                        </Grid>
                    ))}
                </Grid>
            </div>
        </Layout>
    );
}
