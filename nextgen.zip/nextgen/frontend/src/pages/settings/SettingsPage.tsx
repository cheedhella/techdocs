import React from "react";
import {
    Box,
    List,
    ListItemButton,
    ListItemText,
    Typography,
    Paper,
    Grid,
} from "@mui/material";
import Layout from "../LayoutPage";
import { Outlet, useRouter } from "@tanstack/react-router";

type SettingsLink = { label: string; path: string; };
type SettingsGroup = { name: string; links: SettingsLink[] };

const settingsGroups: SettingsGroup[] = [
    {
        name: "Users",
        links: [
            { label: "Create User", path: "create-user" },
            { label: "List Users", path: "list-users" },
            { label: "Change Password", path: "lockout-time" },
        ],
    },
    {
        name: "Groups",
        links: [
            { label: "Create Group", path: "create-user" },
            { label: "List Groups", path: "list-users" },
        ],
    },
    {
        name: "Landscapes",
        links: [
            { label: "Add Landscape", path: "create-user" },
            { label: "List Landscapes", path: "list-users" },
        ],
    },
    {
        name: "MySQL",
        links: [
            { label: "Save Datebase", path: "save-database" },
            { label: "Restore Database", path: "restore-database" },
        ],
    },
    {
        name: "Integrations",
        links: [
            { label: "VNA Integration", path: "vna-integration" },
            { label: "CAPM Integration", path: "capm-database" },
        ],
    },
];

export const SettingsPage: React.FC = () => {
    const router = useRouter();

    return (
        <Layout>
            <Box>
                <Grid container spacing={2}>
                    {/* Grouped links */}
                    {settingsGroups.map((group, idx) => (
                        <Grid item xs={12} sm={6} md={3} key={idx}>
                            <Paper variant="outlined" sx={{ p: 2, height: '100%' }}>
                                <Box mb={2}>
                                    <Typography
                                        variant="subtitle1"
                                        fontWeight="bold"
                                        gutterBottom
                                        sx={{ color: "text.secondary" }}
                                    >
                                        {group.name}
                                    </Typography>
                                    <List disablePadding>
                                        {group.links.map((link, i) => (
                                            <ListItemButton
                                                key={i}
                                                sx={{ pl: 2 }}
                                                onClick={() => {
                                                    router.navigate({ to: `/settings/${link.path}` });
                                                }}
                                            >
                                                <ListItemText
                                                    primary={link.label}
                                                    primaryTypographyProps={{
                                                        color: "primary",
                                                        sx: { textDecoration: "none" },
                                                    }}
                                                />
                                            </ListItemButton>
                                        ))}
                                    </List>
                                </Box>
                            </Paper>
                        </Grid>
                    ))}
                </Grid>

                {/* Renders the selected component when a link is clicked */}
                <Box sx={{ mt: 4 }}>
                    <Outlet />
                </Box>
            </Box>
        </Layout>
    );
};
