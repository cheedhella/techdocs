import { Box, Typography, Button } from '@mui/material';
import Layout from '../LayoutPage';
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useNavigate } from '@tanstack/react-router';

export function NotFound() {
    const navigate = useNavigate();

    return (
        <Layout>
            <Box
                sx={{
                    height: '100vh',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    textAlign: 'center',
                    px: 2,
                }}
            >
                <Typography variant="h1" component="h1" gutterBottom>
                    404
                </Typography>
                <Typography variant="h5" color="text.secondary" gutterBottom>
                    Oops! The page you’re looking for doesn’t exist.
                </Typography>
                <Button
                    variant="outlined"
                    startIcon={<ArrowBackIcon />}
                    onClick={() => navigate({ to: "../home" })}
                    sx={{ mb: 3 }}
                >
                    Go Back Home
                </Button>
            </Box>
        </Layout>
    );
}
