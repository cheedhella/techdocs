/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 2.6.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2023 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/
!function(e){var p;p=function(e,p){return p},"function"===typeof define&&define.amd?define(["./impl/lang","./view-component","./impl/graph-core","./impl/core-lib","./impl/graph-styles-core","./impl/graph-table","./impl/graph-styles-template","./impl/graph-styles-default","./impl/graph-styles-table","./impl/graph-input","./impl/graph-styles-group","./impl/graph-styles-other","./impl/graph-binding","./impl/graph-input-table"],p):"object"===typeof exports&&"undefined"!==typeof module&&"object"===typeof module.exports?module.exports=p(require("./impl/lang"),require("./view-component"),require("./impl/graph-core"),require("./impl/core-lib"),require("./impl/graph-styles-core"),require("./impl/graph-table"),require("./impl/graph-styles-template"),require("./impl/graph-styles-default"),require("./impl/graph-styles-table"),require("./impl/graph-input"),require("./impl/graph-styles-group"),require("./impl/graph-styles-other"),require("./impl/graph-binding"),require("./impl/graph-input-table")):p(e.yfiles.lang,e.yfiles)}("undefined"!==typeof window?window:"undefined"!==typeof global?global:"undefined"!==typeof self?self:this);