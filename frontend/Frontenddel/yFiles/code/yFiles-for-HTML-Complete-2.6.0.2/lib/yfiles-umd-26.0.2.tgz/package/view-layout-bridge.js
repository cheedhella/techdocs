/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 2.6.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2023 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/
!function(e){var r;r=function(e,r){return r},"function"===typeof define&&define.amd?define(["./impl/lang","./view-component","./algorithms","./impl/graph-core","./impl/core-lib","./impl/graph-styles-core","./impl/graph-styles-default","./impl/algorithms","./impl/graph-styles-group","./impl/graph-styles-template","./impl/graph-styles-other","./impl/graph-binding","./impl/layout-core","./impl/graph-layout-bridge"],r):"object"===typeof exports&&"undefined"!==typeof module&&"object"===typeof module.exports?module.exports=r(require("./impl/lang"),require("./view-component"),require("./algorithms"),require("./impl/graph-core"),require("./impl/core-lib"),require("./impl/graph-styles-core"),require("./impl/graph-styles-default"),require("./impl/algorithms"),require("./impl/graph-styles-group"),require("./impl/graph-styles-template"),require("./impl/graph-styles-other"),require("./impl/graph-binding"),require("./impl/layout-core"),require("./impl/graph-layout-bridge")):r(e.yfiles.lang,e.yfiles)}("undefined"!==typeof window?window:"undefined"!==typeof global?global:"undefined"!==typeof self?self:this);