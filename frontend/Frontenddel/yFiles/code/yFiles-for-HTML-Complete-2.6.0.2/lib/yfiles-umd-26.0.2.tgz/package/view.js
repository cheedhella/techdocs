/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 2.6.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2023 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/
!function(e){var i;i=function(e,i){return i},"function"===typeof define&&define.amd?define(["./impl/lang","./view-component","./view-editor","./view-webgl","./view-folding","./view-table","./view-graphml","./impl/graph-core","./impl/core-lib","./impl/graph-styles-core","./impl/graph-styles-default","./impl/graph-table","./impl/graph-styles-template","./impl/graph-folding","./impl/graph-styles-group","./impl/graph-styles-other","./impl/graph-binding","./impl/graph-styles-table","./impl/graph-input","./impl/graph-webgl","./impl/graph-graphml","./impl/graph-input-table"],i):"object"===typeof exports&&"undefined"!==typeof module&&"object"===typeof module.exports?module.exports=i(require("./impl/lang"),require("./view-component"),require("./view-editor"),require("./view-webgl"),require("./view-folding"),require("./view-table"),require("./view-graphml"),require("./impl/graph-core"),require("./impl/core-lib"),require("./impl/graph-styles-core"),require("./impl/graph-styles-default"),require("./impl/graph-table"),require("./impl/graph-styles-template"),require("./impl/graph-folding"),require("./impl/graph-styles-group"),require("./impl/graph-styles-other"),require("./impl/graph-binding"),require("./impl/graph-styles-table"),require("./impl/graph-input"),require("./impl/graph-webgl"),require("./impl/graph-graphml"),require("./impl/graph-input-table")):i(e.yfiles.lang,e.yfiles)}("undefined"!==typeof window?window:"undefined"!==typeof global?global:"undefined"!==typeof self?self:this);